-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Jun 2022 pada 14.50
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `judul` varchar(128) NOT NULL,
  `penulis` varchar(128) NOT NULL,
  `tahun` int(11) NOT NULL,
  `penerbit` varchar(128) NOT NULL,
  `jumlah_buku` int(11) NOT NULL,
  `gambar` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id_buku`, `judul`, `penulis`, `tahun`, `penerbit`, `jumlah_buku`, `gambar`) VALUES
(11, 'Dilan 1990', 'Pidi Baiq', 2014, 'Mizan Pustaka', 2, 'WhatsApp_Image_2022-06-19_at_00_31_00.png'),
(12, 'Dilan 1991', 'Pidi Baiq', 2016, 'Mizan Pustaka', 1, 'WhatsApp_Image_2022-06-19_at_00_05_461.png'),
(13, 'Milea Suara dari Dilan', 'Pidi Baiq', 2016, 'Mizan Pustaka', 1, 'WhatsApp_Image_2022-06-19_at_00_05_46_(1)1.png'),
(14, 'Majalah Bobo Edisi 40', '', 2022, 'Gramedia', 1, 'WhatsApp_Image_2022-06-19_at_00_20_27.png'),
(15, 'Sebuah Seni Untuk Bersikap Bodo Amat', 'Mark Manson', 2018, 'Grasindo', 1, 'WhatsApp_Image_2022-06-19_at_00_23_43.png'),
(16, 'Buku Baru', 'Penulis', 2022, 'Penerbit', 1, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `butuh_konfirmasi`
--

CREATE TABLE `butuh_konfirmasi` (
  `id_sdpinjam` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `status_pinjaman` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id_riwayat` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `tanggal_kembali` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `riwayat`
--

INSERT INTO `riwayat` (`id_riwayat`, `id_user`, `id_buku`, `tanggal_kembali`) VALUES
(68, 13, 11, '2022-06-18 07:19:05');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sedang_dipinjam`
--

CREATE TABLE `sedang_dipinjam` (
  `id_pinjam` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `status_pinjaman` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(128) NOT NULL,
  `user_role` int(11) NOT NULL,
  `auth_pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `user_role`, `auth_pass`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'danielseptyadi@gmail.com', 1, 'admin'),
(11, 'pustakawan', '1fa3f5ae016e4b0691eb5c1b4fd9b951', 'pustakawan@gmail.com', 2, 'pustakawan'),
(12, 'mahasiswa', '5787be38ee03a9ae5360f54d9026465f', 'mahasiswa@gmail.com', 3, 'mahasiswa'),
(13, 'salma', 'f6852b2a3ac0cd7e69c801f69eddb57a', 'salma@gmail.com', 3, 'salma');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'admin'),
(2, 'pustakawan'),
(3, 'mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indeks untuk tabel `butuh_konfirmasi`
--
ALTER TABLE `butuh_konfirmasi`
  ADD PRIMARY KEY (`id_sdpinjam`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`id_riwayat`);

--
-- Indeks untuk tabel `sedang_dipinjam`
--
ALTER TABLE `sedang_dipinjam`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `butuh_konfirmasi`
--
ALTER TABLE `butuh_konfirmasi`
  MODIFY `id_sdpinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  MODIFY `id_riwayat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT untuk tabel `sedang_dipinjam`
--
ALTER TABLE `sedang_dipinjam`
  MODIFY `id_pinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
